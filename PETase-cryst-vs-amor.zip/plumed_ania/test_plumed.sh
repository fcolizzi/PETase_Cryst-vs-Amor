#!/usr/bin/env bash

# loads modules if on cesga
source ~/.projects_startup.sh > /dev/null 2>&1

#for file in $(ls *.dat); do ../test_plumed.sh $file; echo $file; sleep 2 ; done

plumed=${1:-"plumed.dat"}

plumed driver --natoms 100000 --parse-only --kt 2.49 --plumed $plumed #plumed.dat

rm COLVAR HILLS bck.* colvar* 
